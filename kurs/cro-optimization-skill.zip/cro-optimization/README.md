# cro-optimization — CRO-аудит посадкової сторінки

Скіл для Claude Code. Аналізує посадкову сторінку (URL або HTML/CSS)
і видає звіт з конкретними рекомендаціями, що змінити, щоб росла конверсія.

## Встановлення (1 хвилина)

1. Відкрий Claude Code.
2. Перетягни цей архів у чат і напиши:

       встанови цей скилл у ~/.claude/skills/

3. Почни нову сесію.

Ручний варіант: розпакуй і поклади папку `cro-optimization/`
у `~/.claude/skills/` (Windows: `C:\Users\<ім'я>\.claude\skills\`).

## Як викликати

    /cro-optimization https://site.ua/landing

або просто: «зроби CRO-аудит сторінки https://...». Можна вставити HTML/CSS замість URL.

## Що всередині

- `SKILL.md` — логіка аудиту
- `references/cro_principles.md` — принципи, за якими оцінюється сторінка
- `references/element_audit_framework.md` — покроковий розбір елементів
- `references/landing_page_patterns.md` — робочі патерни посадкових
